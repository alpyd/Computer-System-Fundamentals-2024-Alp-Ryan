Alp Demirtas (ademirt1)
Ryan Amer (ramer2)

Assignment 3 MS2:

Ryan worked on the C++ implementation of assignment3.cpp (the main method running the simulator), the Makefile, the README, and fixed bugs in assignment3.cpp and cachesimulator.cpp
Alp worked on the Cache class and the core operations for the cache simulator in cachesimulator.cpp
