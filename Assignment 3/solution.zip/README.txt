Alp Demirtas (ademirt1)
Ryan Amer (ramer2)

Assignment 3:

Ryan worked on a C++ implementation of assignment3.cpp that reads in the number of arguments passed into the program, and he wrote a Makefile that makes a csim file.
Alp worked on the README and tested the code for various arguments. 

There has not been enough code for an interesting implementation, but we will aim to focus on the bigger-picture implementations of the program by writing a skeleton for interpreting each line and the functions, and then handling each of these assignments within the main loop.
To further distinguish the code structure, a cache class can be developed to implement the core methods.